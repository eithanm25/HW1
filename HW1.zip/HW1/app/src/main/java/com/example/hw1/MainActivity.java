package com.example.hw1;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity
{
    private EditText inputValue;
    private Spinner conversionSpinner;
    private Button convertButton;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputValue = findViewById(R.id.inputValue);
        conversionSpinner = findViewById(R.id.conversionSpinner);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);

// Spinner options
        String[] options = {
                "Centimeters → Meters",
                "Meters → Kilometers",
                "Celsius → Fahrenheit",
                "Fahrenheit → Celsius",
                "Grams → Kilograms"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conversionSpinner.setAdapter(adapter);

        convertButton.setOnClickListener(v -> {
            String inputStr = inputValue.getText().toString();
            if (inputStr.isEmpty()) {
                resultText.setText("Invalid input");
                return;
            }

            double input = Double.parseDouble(inputStr);
            double result = 0.0;

            switch (conversionSpinner.getSelectedItem().toString()) {
                case "Centimeters → Meters":
                    result = input / 100;
                    break;
                case "Meters → Kilometers":
                    result = input / 1000;
                    break;
                case "Celsius → Fahrenheit":
                    result = (input * 9 / 5) + 32;
                    break;
                case "Fahrenheit → Celsius":
                    result = (input - 32) * 5 / 9;
                    break;
                case "Grams → Kilograms":
                    result = input / 1000;
                    break;
            }

            resultText.setText(String.valueOf(result));
        });


    }
}